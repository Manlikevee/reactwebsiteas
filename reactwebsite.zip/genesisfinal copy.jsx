import React from "react"
import { Link } from "gatsby"
import { se2 } from './isslbankeasy.module.css'
import { sectcontnt } from './isslbankeasy.module.css'
import { herosectiontext } from './isslbankeasy.module.css'
import { bodycontainer } from './isslbankeasy.module.css'
import { btmsd } from './isslbankeasy.module.css'
import { isslbodyofwork } from './isslbankeasy.module.css'
import { nomediaquerygrid } from './isslbankeasy.module.css'
import { autogrid } from './isslbankeasy.module.css'
import { boxw } from './isslbankeasy.module.css'
import { imside } from './isslbankeasy.module.css'
import { txside } from './isslbankeasy.module.css'
import { txside2} from './isslbankeasy.module.css'
import { txside3 } from './isslbankeasy.module.css'
import { rgtarw } from './isslbankeasy.module.css'
import { nxtscr } from './isslbankeasy.module.css'
import { splitsecond} from './isslbankeasy.module.css'
import { topspanner } from './isslbankeasy.module.css'
import { bottomspanner } from './isslbankeasy.module.css'
import { imageitall} from './isslbankeasy.module.css'
import { oursolution} from './isslbankeasy.module.css'
import { esx } from './isslbankeasy.module.css'
import { solutionsflex1 } from './isslbankeasy.module.css'
import {strech1 } from './isslbankeasy.module.css'
import { ico } from './isslbankeasy.module.css'
import { hed } from './isslbankeasy.module.css'
import { tx} from './isslbankeasy.module.css'
import { strech2 } from './isslbankeasy.module.css'
import { bpn} from './isslbankeasy.module.css'
import { box1 } from './isslbankeasy.module.css'
import { as } from './isslbankeasy.module.css'
import { bs } from './isslbankeasy.module.css'
import { ntnt } from './isslbankeasy.module.css'
import { footersect } from './isslbankeasy.module.css'
import { startconvo } from './isslbankeasy.module.css'
import { fs } from './isslbankeasy.module.css'
import { startconvotxt } from './isslbankeasy.module.css'
import { startconvobtn } from './isslbankeasy.module.css'
import { contactusbtn } from './isslbankeasy.module.css'
import { footergrid } from './isslbankeasy.module.css'
import { logos } from './isslbankeasy.module.css'
import { logo } from './isslbankeasy.module.css'
import { addresssd } from './isslbankeasy.module.css'
import { addre } from './isslbankeasy.module.css'
import { tele } from './isslbankeasy.module.css'
import { mail } from './isslbankeasy.module.css'
import { linksd } from './isslbankeasy.module.css'
import { qkl } from './isslbankeasy.module.css'
import { othlink } from './isslbankeasy.module.css'
import { inputsd } from './isslbankeasy.module.css'
import { getupdat } from './isslbankeasy.module.css'
import { ourproducts } from './isslbankeasy.module.css'
import { howitall } from './isslbankeasy.module.css'
import { tpsd } from './isslbankeasy.module.css'
import { hersec } from './isslbankeasy.module.css'
import { inptbx } from './isslbankeasy.module.css'
import { subbtn } from './isslbankeasy.module.css'

import { paragraph1 } from './isslbankeasy.module.css'
import { hersec3 } from './isslbankeasy.module.css'
import { emptys } from './isslbankeasy.module.css'
import { auto_grid } from './isslbankeasy.module.css'
import { auto_grid2 } from './isslbankeasy.module.css'
import { boxgrid } from './isslbankeasy.module.css'
import { heas } from './isslbankeasy.module.css'
import { bod } from './isslbankeasy.module.css'
import { vision } from './isslbankeasy.module.css'
import { sss } from './isslbankeasy.module.css'
import { dddd } from './isslbankeasy.module.css'
import { sstx } from './isslbankeasy.module.css'
import { ssbod } from './isslbankeasy.module.css'
import { sideofimgs } from './isslbankeasy.module.css'
import {sideofimg} from './isslbankeasy.module.css'

import { rvs } from './isslbankeasy.module.css'
import {sideoftext} from './isslbankeasy.module.css'

import { twosidecontent } from './isslbankeasy.module.css'

import { emp } from './isslbankeasy.module.css'
import { twgrid } from './isslbankeasy.module.css'
import { twgridbod } from './isslbankeasy.module.css'
import { meed } from './isslbankeasy.module.css'
import { bttm } from './isslbankeasy.module.css'

import { bdy } from './isslbankeasy.module.css'
import {hdn} from './isslbankeasy.module.css'

import {hersec2} from './isslbankeasy.module.css'
import {submitting} from './isslbankeasy.module.css'
import {formcontent} from './isslbankeasy.module.css'
import {sideoftext} from './isslbankeasy.module.css'
import {textarea} from './isslbankeasy.module.css'
import {label} from './isslbankeasy.module.css'
import {formcontent} from './isslbankeasy.module.css'
import {slimbod} from './isslbankeasy.module.css'
import {sideoftext} from './isslbankeasy.module.css'
import {slimbod} from './isslbankeasy.module.css'
import {boldhd} from './isslbankeasy.module.css'
import {hersec4} from './isslbankeasy.module.css'
import {sideofimg} from './isslbankeasy.module.css'
import {emp} from './isslbankeasy.module.css'
import {thered} from './isslbankeasy.module.css'
import {contactbtn} from './isslbankeasy.module.css'

import {twgrid} from './isslbankeasy.module.css'
import {twgridbod} from './isslbankeasy.module.css'

import {meed} from './isslbankeasy.module.css'
import {bttm} from './isslbankeasy.module.css'

import {gtstartedlist} from './isslbankeasy.module.css'
import {listcon} from './isslbankeasy.module.css'

import {listribbon} from './isslbankeasy.module.css'
import {listcontent} from './isslbankeasy.module.css'

import {productdiv} from './isslbankeasy.module.css'
import {productsolution} from './isslbankeasy.module.css'

import {solutionbody} from './isslbankeasy.module.css'
import {hersec23} from './isslbankeasy.module.css'


import {pps} from './isslbankeasy.module.css'





import {meimg} from './assets/img/Rectangle 126.png'
import Isslnavbar from '../isslnavbar/index'

import styles from './_styles'
import Myfooter from '../myfooter/index'


const Isslbankeasy = (props) => (

<>
<Isslnavbar />

<>
  <div className={hersec23}>
    <div className={bodycontainer}>
      <div className={tpsd}>
        <h4>
          {" "}
          Stay In Control of Your <br />
          Banking Services{" "}
        </h4>
      </div>
      <p className={pps}>
        Unique banking needs require banking solutions tailored to increase
        productivity and growth.
      </p>
      <div className={mybuttons}>
    <Link to="/contact-us">
        <input
          type="button"
          defaultValue="SCHEDULE A CALL"
          className={thered}
        />
    </Link>
        <a href="mailto:mails@isslng.com ?subject=Integrated Software Services">
            <input type="button" defaultValue="EMAIL US" className={contactbtn} /> 
          </a>
          

      </div>
    </div>
  </div>
  <div className={bodycontainer}></div>
  <div className={bodycontainer}>
    <div className={rvs}>
      <div className={sideoftext}>
        <div className={hdn}>Corporate Banking</div>
        <div className={bdy}>
          We understand the unique banking needs of your corporate clients and
          we are committed to providing solutions that helps provide a
          competitive and flexible banking service. we provide solutions that;
        </div>
        <div className={gtstartedlist}>
          <div className={listcon}>
            <div className={listribbon}>
              <svg
                width={14}
                height={15}
                viewBox="0 0 14 15"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <circle cx="6.875" cy="7.44604" r="6.875" fill="#EB3238" />
              </svg>
            </div>
            <div className={listcontent}>
              Anywhere, anytime and any device customer onboarding capability in
              a matter of minutes
            </div>
          </div>
          <div className={listcon}>
            <div className={listribbon}>
              <svg
                width={14}
                height={15}
                viewBox="0 0 14 15"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <circle cx="6.875" cy="7.44604" r="6.875" fill="#EB3238" />
              </svg>
            </div>
            <div className={listcontent}>Reducing customer onboarding time</div>
          </div>
          <div className={listcon}>
            <div className={listribbon}>
              <svg
                width={14}
                height={15}
                viewBox="0 0 14 15"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <circle cx="6.875" cy="7.44604" r="6.875" fill="#EB3238" />
              </svg>
            </div>
            <div className={listcontent}>
              Reduce the need for customers visits
            </div>
          </div>
          <div className={listcon}>
            <div className={listribbon}>
              <svg
                width={14}
                height={15}
                viewBox="0 0 14 15"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <circle cx="6.875" cy="7.44604" r="6.875" fill="#EB3238" />
              </svg>
            </div>
            <div className={listcontent}>
              Cost savings and operational efficiency through fully automated
              end-to-end processes
            </div>
          </div>
          <div className={listcon}>
            <div className={listribbon}>
              <svg
                width={14}
                height={15}
                viewBox="0 0 14 15"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <circle cx="6.875" cy="7.44604" r="6.875" fill="#EB3238" />
              </svg>
            </div>
            <div className={listcontent}>Enhanced regulatory compliance</div>
          </div>
          <div className={listcon}>
            <div className={listribbon}>
              <svg
                width={14}
                height={15}
                viewBox="0 0 14 15"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <circle cx="6.875" cy="7.44604" r="6.875" fill="#EB3238" />
              </svg>
            </div>
            <div className={listcontent}>Reduced KYC due diligence time</div>
          </div>
        </div>
      </div>
      <div className={sideofimg}>
        <img src="https://github.com/Manlikevee/reactwebsiteas/raw/master/Group%2084%20(2).png" alt="" />
      </div>
    </div>
    <div className={twosidecontent}>
      <div className={sideofimg}>
        <img src="https://github.com/Manlikevee/reactwebsiteas/raw/master/Group%2086%20(2).png" alt="" />
      </div>
      <div className={sideoftext}>
        <div className={hdn}>Retail Banking</div>
        <div className={bdy}>
          We understand the need for mid-size corporate businesses to have the
          right kind of liability products and services that cater to their
          unique banking needs. Our Business Banking service is designed to help
          your business to steadily grow and thrive. we provide solutions that;
        </div>
        <div className={gtstartedlist}>
          <div className={listcon}>
            <div className={listribbon}>
              <svg
                width={14}
                height={15}
                viewBox="0 0 14 15"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <circle cx="6.875" cy="7.44604" r="6.875" fill="#EB3238" />
              </svg>
            </div>
            <div className={listcontent}>
              Anywhere, anytime and any device customer onboarding capability in
              a matter of minutes
            </div>
          </div>
          <div className={listcon}>
            <div className={listribbon}>
              <svg
                width={14}
                height={15}
                viewBox="0 0 14 15"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <circle cx="6.875" cy="7.44604" r="6.875" fill="#EB3238" />
              </svg>
            </div>
            <div className={listcontent}>Reducing customer onboarding time</div>
          </div>
          <div className={listcon}>
            <div className={listribbon}>
              <svg
                width={14}
                height={15}
                viewBox="0 0 14 15"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <circle cx="6.875" cy="7.44604" r="6.875" fill="#EB3238" />
              </svg>
            </div>
            <div className={listcontent}>
              Reduce the need for customers visits
            </div>
          </div>
          <div className={listcon}>
            <div className={listribbon}>
              <svg
                width={14}
                height={15}
                viewBox="0 0 14 15"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <circle cx="6.875" cy="7.44604" r="6.875" fill="#EB3238" />
              </svg>
            </div>
            <div className={listcontent}>
              Cost savings and operational efficiency through fully automated
              end-to-end processes
            </div>
          </div>
          <div className={listcon}>
            <div className={listribbon}>
              <svg
                width={14}
                height={15}
                viewBox="0 0 14 15"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <circle cx="6.875" cy="7.44604" r="6.875" fill="#EB3238" />
              </svg>
            </div>
            <div className={listcontent}>Enhanced regulatory compliance</div>
          </div>
          <div className={listcon}>
            <div className={listribbon}>
              <svg
                width={14}
                height={15}
                viewBox="0 0 14 15"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <circle cx="6.875" cy="7.44604" r="6.875" fill="#EB3238" />
              </svg>
            </div>
            <div className={listcontent}>Reduced KYC due diligence time</div>
          </div>
        </div>
      </div>
    </div>
    <div className={rvs}>
      <div className={sideoftext}>
        <div className={hdn}>Investment Banking</div>
        <div className={bdy}>
          We understand the need for mid-size corporate businesses to have the
          right kind of liability products and services that cater to their
          unique banking needs. Our Business Banking service is designed to help
          your business to steadily grow and thrive. we provide solutions that;
        </div>
        <div className={gtstartedlist}>
          <div className={listcon}>
            <div className={listribbon}>
              <svg
                width={14}
                height={15}
                viewBox="0 0 14 15"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <circle cx="6.875" cy="7.44604" r="6.875" fill="#EB3238" />
              </svg>
            </div>
            <div className={listcontent}>
              Anywhere, anytime and any device customer onboarding capability in
              a matter of minutes
            </div>
          </div>
          <div className={listcon}>
            <div className={listribbon}>
              <svg
                width={14}
                height={15}
                viewBox="0 0 14 15"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <circle cx="6.875" cy="7.44604" r="6.875" fill="#EB3238" />
              </svg>
            </div>
            <div className={listcontent}>Reducing customer onboarding time</div>
          </div>
          <div className={listcon}>
            <div className={listribbon}>
              <svg
                width={14}
                height={15}
                viewBox="0 0 14 15"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <circle cx="6.875" cy="7.44604" r="6.875" fill="#EB3238" />
              </svg>
            </div>
            <div className={listcontent}>
              Reduce the need for customers visits
            </div>
          </div>
          <div className={listcon}>
            <div className={listribbon}>
              <svg
                width={14}
                height={15}
                viewBox="0 0 14 15"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <circle cx="6.875" cy="7.44604" r="6.875" fill="#EB3238" />
              </svg>
            </div>
            <div className={listcontent}>
              Cost savings and operational efficiency through fully automated
              end-to-end processes
            </div>
          </div>
          <div className={listcon}>
            <div className={listribbon}>
              <svg
                width={14}
                height={15}
                viewBox="0 0 14 15"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <circle cx="6.875" cy="7.44604" r="6.875" fill="#EB3238" />
              </svg>
            </div>
            <div className={listcontent}>Enhanced regulatory compliance</div>
          </div>
          <div className={listcon}>
            <div className={listribbon}>
              <svg
                width={14}
                height={15}
                viewBox="0 0 14 15"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <circle cx="6.875" cy="7.44604" r="6.875" fill="#EB3238" />
              </svg>
            </div>
            <div className={listcontent}>Reduced KYC due diligence time</div>
          </div>
        </div>
      </div>
      <div className={sideofimg}>
        <img src="https://github.com/Manlikevee/reactwebsiteas/raw/master/Group%2094%20(2).png" alt="" />
      </div>
    </div>
    <p className={productsolution}>Our Product Solutions</p>
    <p className={solutionbody}>
      Whether you are just starting up or looking to grow your business, we have
      the product solution that works just right for you
    </p>
    <div className={productdiv}>
      <div className={product}>
        <div className={prodimg}>
          <svg
            width={88}
            height={91}
            viewBox="0 0 88 91"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <ellipse
              cx="25.553"
              cy="24.8353"
              rx="25.4836"
              ry="24.5003"
              fill="#3A3A85"
              fillOpacity="0.15"
            />
            <path
              d="M37.2201 81H20.5534C18.7853 81 17.0896 80.2976 15.8393 79.0474C14.5891 77.7971 13.8867 76.1014 13.8867 74.3333V27.6667C13.8867 25.8986 14.5891 24.2029 15.8393 22.9526C17.0896 21.7024 18.7853 21 20.5534 21H73.8867C75.6548 21 77.3505 21.7024 78.6008 22.9526C79.851 24.2029 80.5534 25.8986 80.5534 27.6667V47.6667"
              stroke="#3A3A85"
              strokeWidth="5.64586"
              strokeLinecap="round"
            />
            <path
              d="M43.8867 27.7L43.9201 27.6633M47.2201 81V65.5367C47.2201 63.8367 47.5534 62.2067 48.1667 60.6933L47.2201 81ZM80.5534 81V70.3833V81ZM54.6267 53.45C57.4421 51.8281 60.6376 50.9826 63.8867 51C71.4867 51 77.8967 55.4333 79.9034 61.5L54.6267 53.45ZM57.2201 84.3333V77.0767V84.3333ZM70.5534 84.3333V67.1767C70.5534 63.7667 67.5701 61 63.8867 61C60.2034 61 57.2201 63.7667 57.2201 67.1767V69.8233L70.5534 84.3333ZM13.8867 34.3333H80.5534H13.8867ZM23.8867 27.7L23.9201 27.6633L23.8867 27.7ZM33.8867 27.7L33.9201 27.6633L33.8867 27.7Z"
              stroke="#3A3A85"
              strokeWidth="5.64586"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </div>
        <div className={prodtitle}>Digital Onboarding Solution</div>
      </div>
      <div className={product}>
        <div className={prodimg}>
          <svg
            width={89}
            height={95}
            viewBox="0 0 89 95"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <circle
              cx="26.3909"
              cy="26.1797"
              r="25.4836"
              fill="#3A3A85"
              fillOpacity="0.15"
            />
            <path
              d="M43.0576 50.8333C43.0576 51.8182 42.8636 52.7935 42.4867 53.7035C42.1098 54.6134 41.5574 55.4402 40.8609 56.1366C40.1645 56.8331 39.3377 57.3855 38.4277 57.7624C37.5178 58.1393 36.5425 58.3333 35.5576 58.3333C34.5727 58.3333 33.5974 58.1393 32.6875 57.7624C31.7775 57.3855 30.9508 56.8331 30.2543 56.1366C29.5579 55.4402 29.0054 54.6134 28.6285 53.7035C28.2516 52.7935 28.0576 51.8182 28.0576 50.8333C28.0576 48.8442 28.8478 46.9366 30.2543 45.53C31.6608 44.1235 33.5685 43.3333 35.5576 43.3333C37.5467 43.3333 39.4544 44.1235 40.8609 45.53C42.2674 46.9366 43.0576 48.8442 43.0576 50.8333ZM38.8909 50.8333C38.8909 49.9493 38.5398 49.1014 37.9146 48.4763C37.2895 47.8512 36.4417 47.5 35.5576 47.5C34.6736 47.5 33.8257 47.8512 33.2006 48.4763C32.5755 49.1014 32.2243 49.9493 32.2243 50.8333C32.2243 51.7174 32.5755 52.5652 33.2006 53.1904C33.8257 53.8155 34.6736 54.1667 35.5576 54.1667C36.4417 54.1667 37.2895 53.8155 37.9146 53.1904C38.5398 52.5652 38.8909 51.7174 38.8909 50.8333ZM35.5576 76.6667C37.5467 76.6667 39.4544 75.8765 40.8609 74.47C42.2674 73.0634 43.0576 71.1558 43.0576 69.1667C43.0576 67.1775 42.2674 65.2699 40.8609 63.8634C39.4544 62.4568 37.5467 61.6667 35.5576 61.6667C33.5685 61.6667 31.6608 62.4568 30.2543 63.8634C28.8478 65.2699 28.0576 67.1775 28.0576 69.1667C28.0576 71.1558 28.8478 73.0634 30.2543 74.47C31.6608 75.8765 33.5685 76.6667 35.5576 76.6667ZM35.5576 72.5C34.6736 72.5 33.8257 72.1488 33.2006 71.5237C32.5755 70.8986 32.2243 70.0507 32.2243 69.1667C32.2243 68.2826 32.5755 67.4348 33.2006 66.8096C33.8257 66.1845 34.6736 65.8333 35.5576 65.8333C36.4417 65.8333 37.2895 66.1845 37.9146 66.8096C38.5398 67.4348 38.8909 68.2826 38.8909 69.1667C38.8909 70.0507 38.5398 70.8986 37.9146 71.5237C37.2895 72.1488 36.4417 72.5 35.5576 72.5ZM30.141 35C29.5884 35 29.0585 35.2195 28.6678 35.6102C28.2771 36.0009 28.0576 36.5308 28.0576 37.0833C28.0576 37.6359 28.2771 38.1658 28.6678 38.5565C29.0585 38.9472 29.5884 39.1667 30.141 39.1667H65.9743C66.5268 39.1667 67.0567 38.9472 67.4474 38.5565C67.8381 38.1658 68.0576 37.6359 68.0576 37.0833C68.0576 36.5308 67.8381 36.0009 67.4474 35.6102C67.0567 35.2195 66.5268 35 65.9743 35H30.141ZM46.3909 51.25C46.3909 50.1 47.3243 49.1667 48.4743 49.1667H65.9743C66.5268 49.1667 67.0567 49.3862 67.4474 49.7769C67.8381 50.1676 68.0576 50.6975 68.0576 51.25C68.0576 51.8025 67.8381 52.3324 67.4474 52.7231C67.0567 53.1138 66.5268 53.3333 65.9743 53.3333H48.4743C47.3243 53.3333 46.3909 52.4 46.3909 51.25ZM48.4743 66.6667C47.9217 66.6667 47.3918 66.8862 47.0011 67.2769C46.6104 67.6676 46.3909 68.1975 46.3909 68.75C46.3909 69.3025 46.6104 69.8324 47.0011 70.2231C47.3918 70.6138 47.9217 70.8333 48.4743 70.8333H65.9743C66.5268 70.8333 67.0567 70.6138 67.4474 70.2231C67.8381 69.8324 68.0576 69.3025 68.0576 68.75C68.0576 68.1975 67.8381 67.6676 67.4474 67.2769C67.0567 66.8862 66.5268 66.6667 65.9743 66.6667H48.4743ZM28.4743 25C25.7116 25 23.0621 26.0975 21.1086 28.051C19.1551 30.0045 18.0576 32.654 18.0576 35.4167V74.5833C18.0576 77.346 19.1551 79.9955 21.1086 81.949C23.0621 83.9025 25.7116 85 28.4743 85H67.6409C70.4036 85 73.0531 83.9025 75.0066 81.949C76.9602 79.9955 78.0576 77.346 78.0576 74.5833V35.4167C78.0576 32.654 76.9602 30.0045 75.0066 28.051C73.0531 26.0975 70.4036 25 67.6409 25H28.4743ZM22.2243 35.4167C22.2243 33.7591 22.8828 32.1694 24.0549 30.9972C25.227 29.8251 26.8167 29.1667 28.4743 29.1667H67.6409C69.2986 29.1667 70.8883 29.8251 72.0604 30.9972C73.2325 32.1694 73.8909 33.7591 73.8909 35.4167V74.5833C73.8909 76.2409 73.2325 77.8306 72.0604 79.0027C70.8883 80.1749 69.2986 80.8333 67.6409 80.8333H28.4743C26.8167 80.8333 25.227 80.1749 24.0549 79.0027C22.8828 77.8306 22.2243 76.2409 22.2243 74.5833V35.4167Z"
              fill="#3A3A85"
            />
          </svg>
        </div>
        <div className={prodtitle}>E-KYC Solution</div>
      </div>
      <div className={product}>
        <div className={prodimg}>
          <svg
            width={81}
            height={80}
            viewBox="0 0 81 80"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <g clipPath="url(#clip0_1930_1944)">
              <path
                d="M8.67416 30.1332L40.8964 11.6221L73.1186 30.1332C73.6265 30.3989 74.2173 30.4581 74.7678 30.2984C75.3183 30.1387 75.7857 29.7725 76.0726 29.2762C76.3594 28.78 76.4434 28.1922 76.3071 27.6354C76.1707 27.0787 75.8245 26.5963 75.3408 26.2888L40.8964 6.48877L6.45193 26.2888C6.18637 26.4277 5.95165 26.6189 5.76189 26.8509C5.57214 27.0829 5.43127 27.3508 5.34776 27.6387C5.26426 27.9265 5.23984 28.2283 5.27598 28.5258C5.31212 28.8233 5.40807 29.1105 5.55806 29.3699C5.70805 29.6294 5.90897 29.8559 6.14875 30.0357C6.38852 30.2155 6.66219 30.345 6.9533 30.4163C7.2444 30.4876 7.54692 30.4992 7.84265 30.4506C8.13839 30.402 8.42123 30.294 8.67416 30.1332Z"
                fill="#3A3A85"
              />
              <path
                d="M9.78516 57.7775C9.78516 58.3669 10.0193 58.9321 10.436 59.3488C10.8528 59.7656 11.418 59.9997 12.0074 59.9997H69.7852C70.3745 59.9997 70.9398 59.7656 71.3565 59.3488C71.7733 58.9321 72.0074 58.3669 72.0074 57.7775C72.0074 57.1881 71.7733 56.6229 71.3565 56.2061C70.9398 55.7894 70.3745 55.5553 69.7852 55.5553H63.1185V39.1775H58.674V55.5553H43.1185V39.1775H38.674V55.5553H23.1185V39.1775H18.674V55.5553H12.0074C11.418 55.5553 10.8528 55.7894 10.436 56.2061C10.0193 56.6229 9.78516 57.1881 9.78516 57.7775Z"
                fill="#3A3A85"
              />
              <path
                d="M12.0518 31.1111H69.8295V35.5555H12.0518V31.1111Z"
                fill="#3A3A85"
              />
              <path
                d="M74.2297 64.4443H7.56304C6.97367 64.4443 6.40844 64.6785 5.99169 65.0952C5.57495 65.512 5.34082 66.0772 5.34082 66.6666C5.34082 67.2559 5.57495 67.8212 5.99169 68.2379C6.40844 68.6547 6.97367 68.8888 7.56304 68.8888H74.2297C74.8191 68.8888 75.3843 68.6547 75.8011 68.2379C76.2178 67.8212 76.4519 67.2559 76.4519 66.6666C76.4519 66.0772 76.2178 65.512 75.8011 65.0952C75.3843 64.6785 74.8191 64.4443 74.2297 64.4443Z"
                fill="#3A3A85"
              />
              <path
                d="M50.1188 25.7334H57.2521L42.341 17.1557C42.0707 16.9996 41.7642 16.9175 41.4521 16.9175C41.14 16.9175 40.8335 16.9996 40.5632 17.1557L25.6299 25.7334H32.7632L41.4299 20.7557L50.1188 25.7334Z"
                fill="#3A3A85"
              />
            </g>
            <defs>
              <clipPath id="clip0_1930_1944">
                <rect
                  width={80}
                  height={80}
                  fill="white"
                  transform="translate(0.896484)"
                />
              </clipPath>
            </defs>
          </svg>
        </div>
        <div className={prodtitle}>Core Banking Application</div>
      </div>
      <div className={product}>
        <div className={prodimg}>
          <svg
            width={88}
            height={95}
            viewBox="0 0 88 95"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M19.8301 33C19.8301 31.4087 20.4622 29.8826 21.5874 28.7574C22.7127 27.6321 24.2388 27 25.8301 27H69.8301C71.4214 27 72.9475 27.6321 74.0727 28.7574C75.1979 29.8826 75.8301 31.4087 75.8301 33V61C75.8301 62.5913 75.1979 64.1174 74.0727 65.2426C72.9475 66.3679 71.4214 67 69.8301 67H47.8301V63H69.8301C70.3605 63 70.8692 62.7893 71.2443 62.4142C71.6194 62.0391 71.8301 61.5304 71.8301 61V33C71.8301 32.4696 71.6194 31.9609 71.2443 31.5858C70.8692 31.2107 70.3605 31 69.8301 31H25.8301C25.2996 31 24.7909 31.2107 24.4159 31.5858C24.0408 31.9609 23.8301 32.4696 23.8301 33V39H19.8301V33ZM47.8301 75H77.8301C78.3605 75 78.8692 74.7893 79.2443 74.4142C79.6194 74.0391 79.8301 73.5304 79.8301 73C79.8301 72.4696 79.6194 71.9609 79.2443 71.5858C78.8692 71.2107 78.3605 71 77.8301 71H47.8301V75ZM27.8301 75C27.2996 75 26.7909 75.2107 26.4159 75.5858C26.0408 75.9609 25.8301 76.4696 25.8301 77C25.8301 77.5304 26.0408 78.0391 26.4159 78.4142C26.7909 78.7893 27.2996 79 27.8301 79H31.8301C32.3605 79 32.8692 78.7893 33.2443 78.4142C33.6194 78.0391 33.8301 77.5304 33.8301 77C33.8301 76.4696 33.6194 75.9609 33.2443 75.5858C32.8692 75.2107 32.3605 75 31.8301 75H27.8301ZM15.8301 49C15.8301 47.4087 16.4622 45.8826 17.5874 44.7574C18.7127 43.6321 20.2388 43 21.8301 43H37.8301C39.4214 43 40.9475 43.6321 42.0727 44.7574C43.1979 45.8826 43.8301 47.4087 43.8301 49V81C43.8301 82.5913 43.1979 84.1174 42.0727 85.2426C40.9475 86.3679 39.4214 87 37.8301 87H21.8301C20.2388 87 18.7127 86.3679 17.5874 85.2426C16.4622 84.1174 15.8301 82.5913 15.8301 81V49ZM21.8301 47C21.2996 47 20.7909 47.2107 20.4159 47.5858C20.0408 47.9609 19.8301 48.4696 19.8301 49V81C19.8301 81.5304 20.0408 82.0391 20.4159 82.4142C20.7909 82.7893 21.2996 83 21.8301 83H37.8301C38.3605 83 38.8692 82.7893 39.2443 82.4142C39.6194 82.0391 39.8301 81.5304 39.8301 81V49C39.8301 48.4696 39.6194 47.9609 39.2443 47.5858C38.8692 47.2107 38.3605 47 37.8301 47H21.8301Z"
              fill="#3A3A85"
            />
            <circle
              cx="26.1633"
              cy="26.1797"
              r="25.4836"
              fill="#3A3A85"
              fillOpacity="0.15"
            />
          </svg>
        </div>
        <div className={prodtitle}>Web &amp; Mobile App Development</div>
      </div>
    </div>
  </div>
</>




import { smedia } from './footernew.module.css'
import { fb } from './footernew.module.css'

<div className={smedia}>
  <div className={fb}>
    <span>
      <svg
        width={10}
        height={18}
        viewBox="0 0 10 18"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M2.43144 17.9665H6.09811V10.624H9.40177L9.76477 6.97564H6.09811V5.13314C6.09811 4.89002 6.19468 4.65687 6.36659 4.48496C6.5385 4.31305 6.77166 4.21647 7.01477 4.21647H9.76477V0.549805H7.01477C5.7992 0.549805 4.63341 1.03269 3.77387 1.89223C2.91433 2.75177 2.43144 3.91756 2.43144 5.13314V6.97564H0.598107L0.235107 10.624H2.43144V17.9665Z"
          fill="#EB3238"
        />
      </svg>
    </span>
  </div>
  <div className={fb}>
    <span>
      <svg
        width={20}
        height={16}
        viewBox="0 0 20 16"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M19.7025 2.37196C19.0067 2.6803 18.2592 2.88863 17.4733 2.9828C18.2842 2.49762 18.8908 1.73402 19.18 0.834462C18.4182 1.28695 17.5844 1.60546 16.715 1.77613C16.1303 1.15185 15.3559 0.738067 14.5119 0.599024C13.668 0.45998 12.8017 0.603455 12.0477 1.00717C11.2936 1.41089 10.694 2.05226 10.3418 2.83172C9.9896 3.61117 9.9046 4.48509 10.1 5.3178C8.55639 5.24029 7.04635 4.83909 5.66784 4.14022C4.28934 3.44135 3.07319 2.46043 2.09832 1.26113C1.76499 1.83613 1.57332 2.5028 1.57332 3.2128C1.57295 3.85196 1.73035 4.48133 2.03155 5.04507C2.33276 5.60881 2.76846 6.08949 3.29999 6.44446C2.68355 6.42485 2.08072 6.25828 1.54166 5.95863V6.00863C1.54159 6.90508 1.85168 7.77394 2.41931 8.46779C2.98693 9.16164 3.77713 9.63774 4.65582 9.8153C4.08398 9.97006 3.48444 9.99286 2.90249 9.88196C3.1504 10.6533 3.63332 11.3278 4.28363 11.8111C4.93394 12.2943 5.71909 12.5621 6.52916 12.577C5.15402 13.6565 3.45573 14.242 1.70749 14.2395C1.39781 14.2395 1.08839 14.2215 0.780823 14.1853C2.55539 15.3263 4.62111 15.9318 6.73082 15.9295C13.8725 15.9295 17.7767 10.0145 17.7767 4.88446C17.7767 4.7178 17.7725 4.54946 17.765 4.3828C18.5244 3.83361 19.1799 3.15354 19.7008 2.37446L19.7025 2.37196Z"
          fill="#EB3238"
        />
      </svg>
    </span>
  </div>
  <div className={fb}>
    <span>
      <a href="mailto:mails@isslng.com ?subject=Integrated Software Services">
        <svg
          width={20}
          height={15}
          viewBox="0 0 20 15"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M2.30769 0.334717C1.03385 0.334717 0 1.36856 0 2.64241V11.8732C0 13.147 1.03385 14.1809 2.30769 14.1809H17.6923C18.9662 14.1809 20 13.147 20 11.8732V2.64241C20 1.36856 18.9662 0.334717 17.6923 0.334717H2.30769ZM2.30769 1.87318H17.6923C18.1162 1.87318 18.4615 2.21856 18.4615 2.64241V3.02702L10 7.59472L1.53846 3.02702V2.64241C1.53846 2.21856 1.88385 1.87318 2.30769 1.87318ZM1.53846 3.24318L6.56231 7.16164L1.63462 12.2101L7.64462 7.93087L10 9.44549L12.3562 7.93087L18.3654 12.2101L13.4377 7.16164L18.4615 3.24318V11.8732C18.4573 11.9916 18.4243 12.1073 18.3654 12.2101C18.2385 12.4601 17.9915 12.6424 17.6923 12.6424H2.30769C2.00846 12.6424 1.76154 12.4601 1.63462 12.2093C1.57584 12.1067 1.54284 11.9914 1.53846 11.8732V3.24318Z"
            fill="#EB3238"
          />
        </svg>
      </a>
    </span>
  </div>
  <div className={fb}>
    <span>
      <svg
        width={20}
        height={21}
        viewBox="0 0 20 21"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M17.0012 3.16537C16.0843 2.23997 14.9924 1.5063 13.7891 1.00713C12.5858 0.507957 11.2952 0.253257 9.9925 0.257874C4.53375 0.257874 0.085 4.70537 0.08 10.1654C0.08 11.9141 0.5375 13.6154 1.40125 15.1216L0 20.2579L5.255 18.8804C6.70876 19.6715 8.33741 20.0862 9.9925 20.0866H9.9975C15.4575 20.0866 19.905 15.6391 19.91 10.1741C19.9112 8.87168 19.6548 7.58186 19.1553 6.37897C18.6559 5.17609 17.9234 4.08391 17 3.16537H17.0012ZM9.9925 18.4091C8.51625 18.4096 7.06713 18.0124 5.7975 17.2591L5.4975 17.0791L2.38 17.8966L3.2125 14.8554L3.0175 14.5416C2.19226 13.2295 1.75581 11.7104 1.75875 10.1604C1.75875 5.62787 5.455 1.93037 9.9975 1.93037C11.0797 1.92843 12.1515 2.14072 13.1513 2.55499C14.151 2.96926 15.0589 3.57732 15.8225 4.34412C16.5888 5.10794 17.1963 6.01591 17.6099 7.01566C18.0235 8.01542 18.2351 9.08718 18.2325 10.1691C18.2275 14.7179 14.5312 18.4091 9.9925 18.4091ZM14.5113 12.2416C14.265 12.1179 13.0487 11.5191 12.82 11.4341C12.5925 11.3529 12.4262 11.3104 12.2638 11.5579C12.0975 11.8041 11.6225 12.3654 11.48 12.5266C11.3375 12.6929 11.19 12.7116 10.9425 12.5891C10.6962 12.4641 9.8975 12.2041 8.9525 11.3579C8.215 10.7016 7.72125 9.88912 7.57375 9.64287C7.43125 9.39537 7.56 9.26287 7.68375 9.13912C7.7925 9.02912 7.93 8.84912 8.05375 8.70662C8.17875 8.56412 8.22 8.45912 8.30125 8.29412C8.3825 8.12662 8.34375 7.98412 8.2825 7.86037C8.22 7.73662 7.72625 6.51537 7.5175 6.02287C7.3175 5.53662 7.11375 5.60412 6.96125 5.59787C6.81875 5.58912 6.6525 5.58912 6.48625 5.58912C6.3607 5.59224 6.23716 5.62128 6.12337 5.67441C6.00958 5.72754 5.90799 5.80362 5.825 5.89787C5.5975 6.14537 4.96125 6.74412 4.96125 7.96537C4.96125 9.18662 5.84875 10.3604 5.97375 10.5266C6.09625 10.6929 7.71625 13.1916 10.2025 14.2666C10.79 14.5229 11.2525 14.6741 11.6138 14.7891C12.2075 14.9791 12.7437 14.9504 13.1712 14.8891C13.6462 14.8166 14.635 14.2891 14.8438 13.7104C15.0487 13.1304 15.0488 12.6354 14.9862 12.5316C14.925 12.4266 14.7587 12.3654 14.5113 12.2416Z"
          fill="#EB3238"
        />
      </svg>
    </span>
  </div>
</div>











<Myfooter />
  
</>

)

export default Isslbankeasy