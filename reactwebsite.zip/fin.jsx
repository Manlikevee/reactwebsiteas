import React from "react"
import { Link } from "gatsby"

import { se2 } from './isslauth.module.css'
import { sectcontnt } from './isslauth.module.css'
import { herosectiontext } from './isslauth.module.css'
import { bodycontainer } from './isslauth.module.css'
import { btmsd } from './isslauth.module.css'
import { isslbodyofwork } from './isslauth.module.css'
import { nomediaquerygrid } from './isslauth.module.css'
import { autogrid } from './isslauth.module.css'
import { boxw } from './isslauth.module.css'
import { imside } from './isslauth.module.css'
import { txside } from './isslauth.module.css'
import { txside2} from './isslauth.module.css'
import { txside3 } from './isslauth.module.css'
import { rgtarw } from './isslauth.module.css'
import { nxtscr } from './isslauth.module.css'
import { splitsecond} from './isslauth.module.css'
import { topspanner } from './isslauth.module.css'
import { bottomspanner } from './isslauth.module.css'
import { imageitall} from './isslauth.module.css'
import { oursolution} from './isslauth.module.css'
import { esx } from './isslauth.module.css'
import { solutionsflex1 } from './isslauth.module.css'
import {strech1 } from './isslauth.module.css'
import { ico } from './isslauth.module.css'
import { hed } from './isslauth.module.css'
import { tx} from './isslauth.module.css'
import { strech2 } from './isslauth.module.css'
import { bpn} from './isslauth.module.css'
import { box1 } from './isslauth.module.css'
import { as } from './isslauth.module.css'
import { bs } from './isslauth.module.css'
import { ntnt } from './isslauth.module.css'
import { footersect } from './isslauth.module.css'
import { startconvo } from './isslauth.module.css'
import { fs } from './isslauth.module.css'
import { startconvotxt } from './isslauth.module.css'
import { startconvobtn } from './isslauth.module.css'
import { contactusbtn } from './isslauth.module.css'
import { footergrid } from './isslauth.module.css'
import { logos } from './isslauth.module.css'
import { logo } from './isslauth.module.css'
import { addresssd } from './isslauth.module.css'
import { addre } from './isslauth.module.css'
import { tele } from './isslauth.module.css'
import { mail } from './isslauth.module.css'
import { linksd } from './isslauth.module.css'
import { qkl } from './isslauth.module.css'
import { othlink } from './isslauth.module.css'
import { inputsd } from './isslauth.module.css'
import { getupdat } from './isslauth.module.css'
import { ourproducts } from './isslauth.module.css'
import { howitall } from './isslauth.module.css'
import { tpsd } from './isslauth.module.css'
import { hersec } from './isslauth.module.css'
import { inptbx } from './isslauth.module.css'
import { subbtn } from './isslauth.module.css'
import { toop } from './isslauth.module.css'
import { paragraph1 } from './isslauth.module.css'
import { hersec3 } from './isslauth.module.css'
import { emptys } from './isslauth.module.css'
import { auto_grid } from './isslauth.module.css'
import { auto_grid2 } from './isslauth.module.css'
import { boxgrid } from './isslauth.module.css'
import { heas } from './isslauth.module.css'
import { bod } from './isslauth.module.css'
import { vision } from './isslauth.module.css'
import { sss } from './isslauth.module.css'
import { dddd } from './isslauth.module.css'
import { sstx } from './isslauth.module.css'
import { ssbod } from './isslauth.module.css'
import { sideofimgs } from './isslauth.module.css'
import {sideofimg} from './isslauth.module.css'

import { rvs } from './isslauth.module.css'
import {sideoftext} from './isslauth.module.css'

import { twosidecontent } from './isslauth.module.css'

import { emp } from './isslauth.module.css'
import { twgrid } from './isslauth.module.css'
import { twgridbod } from './isslauth.module.css'
import { meed } from './isslauth.module.css'
import { bttm } from './isslauth.module.css'

import { bdy } from './isslauth.module.css'
import {hdn} from './isslauth.module.css'

import {hersec2} from './isslauth.module.css'


import {meimg} from './assets/img/Rectangle 126.png'
import Isslnavbar from '../isslnavbar/index'

import styles from './_styles'
import Myfooter from '../myfooter/index'


const Isslbankingsolutions = (props) => (

<>
<Isslnavbar />


<div className={sectcontnt}>
  <div className={hersec2}>
    <div className={bodycontainer}>
      <div className={tpsd}>
        <h3 className={tpsd}>
          {" "}
          <p>Re-think applications; </p>
          Re-imagine business
        </h3>
      </div>
    </div>
  </div>
  <div className={bodycontainer}>
    <div className={emptys}>
      <div className={rvs}>
        <div className={sideoftext}>
          <div className={hdn}>Banking system revolution</div>
          <div className={bdy}>
          From internet banking and mobile banking to real-time core banking and Know Your Customer (KYC) solutions, Africa is witnessing a banking system revolution. Today, competitive banks need to offer a combination of online banking and branch solutions that do everything from allowing a customer to send a mobile payment, to checking the verification of a new customer through KYC rules and regulations.


          </div>
        </div>
        <div className={sideofimg}>
          <img
            src="https://github.com/Manlikevee/reactwebsiteas/raw/master/business-3d-e-wallet-in-a-phone-with-bank-card-stack-of-coins-and-leather-wallet%201%20(12).png"
            alt=""
          />
        </div>
      </div>
      <div className={isslbodyofwork}>
      ISSL offers a combination of online banking and branch solutions that do everything from allowing a customer to send a mobile payment, to checking the verification of a new customer through KYC rules and regulations.


      </div>
    </div>
  </div>
  <div className={emp}>
    <div className={bodycontainer}>
      <div className={twgrid}>
        <div className={twgridbod}>
          <div className={toop}>
 

          <svg width="57" height="61" viewBox="0 0 57 61" fill="none" xmlns="http://www.w3.org/2000/svg">
<g clip-path="url(#clip0_1966_1669)">
<path d="M10.3475 28.6024L30.8486 16.8249L51.3497 28.6024C51.6728 28.7714 52.0488 28.8091 52.399 28.7075C52.7492 28.6059 53.0467 28.3729 53.2292 28.0571C53.4117 27.7414 53.4651 27.3674 53.3783 27.0132C53.2916 26.659 53.0713 26.352 52.7636 26.1564L30.8486 13.5588L8.93368 26.1564C8.76471 26.2448 8.61537 26.3664 8.49464 26.514C8.37391 26.6616 8.28429 26.8321 8.23116 27.0153C8.17803 27.1984 8.16249 27.3904 8.18549 27.5797C8.20848 27.769 8.26953 27.9517 8.36496 28.1168C8.46038 28.2819 8.58822 28.4259 8.74078 28.5403C8.89333 28.6547 9.06745 28.7371 9.25266 28.7825C9.43788 28.8278 9.63035 28.8353 9.81851 28.8043C10.0067 28.7734 10.1866 28.7047 10.3475 28.6024Z" fill="#3A3A85"/>
<path d="M11.0544 46.1909C11.0544 46.5659 11.2034 46.9255 11.4686 47.1906C11.7337 47.4558 12.0933 47.6048 12.4683 47.6048H49.2289C49.6039 47.6048 49.9635 47.4558 50.2286 47.1906C50.4938 46.9255 50.6427 46.5659 50.6427 46.1909C50.6427 45.8159 50.4938 45.4563 50.2286 45.1911C49.9635 44.926 49.6039 44.777 49.2289 44.777H44.9873V34.3568H42.1595V44.777H32.2625V34.3568H29.4347V44.777H19.5377V34.3568H16.7099V44.777H12.4683C12.0933 44.777 11.7337 44.926 11.4686 45.1911C11.2034 45.4563 11.0544 45.8159 11.0544 46.1909Z" fill="#3A3A85"/>
<path d="M12.4967 29.2246H49.2573V32.0523H12.4967V29.2246Z" fill="#3A3A85"/>
<path d="M52.0567 50.4326H9.64067C9.26569 50.4326 8.90607 50.5816 8.64092 50.8467C8.37577 51.1119 8.22681 51.4715 8.22681 51.8465C8.22681 52.2215 8.37577 52.5811 8.64092 52.8462C8.90607 53.1114 9.26569 53.2604 9.64067 53.2604H52.0567C52.4317 53.2604 52.7913 53.1114 53.0565 52.8462C53.3216 52.5811 53.4706 52.2215 53.4706 51.8465C53.4706 51.4715 53.3216 51.1119 53.0565 50.8467C52.7913 50.5816 52.4317 50.4326 52.0567 50.4326Z" fill="#3A3A85"/>
<path d="M36.7162 25.803H41.2547L31.7677 20.3455C31.5957 20.2462 31.4007 20.194 31.2021 20.194C31.0036 20.194 30.8085 20.2462 30.6366 20.3455L21.1354 25.803H25.6739L31.188 22.636L36.7162 25.803Z" fill="#3A3A85"/>
</g>
<circle cx="17.0633" cy="16.5434" r="16.2137" fill="#3A3A85" fill-opacity="0.15"/>
<defs>
<clipPath id="clip0_1966_1669">
<rect width="50.8992" height="50.8992" fill="white" transform="translate(5.39905 9.43048)"/>
</clipPath>
</defs>
</svg>

              

          </div>
          <div className={meed}>Core Banking</div>
          <div className={bttm}>
        
          ISSL’s core banking solution, IntegraBanking Products, will allow your customers to do just that. What’s more, IntegraBanking will integrate your accounting, transaction handling, customer service and management reporting into one system, making it easier and faster for your employees to handle your customers’ requests. Becoming a more efficient bank has never been so easy!



          </div>
        </div>
        <div className={twgridbod}>
          <div className={toop}>
    


          <svg width="52" height="52" viewBox="0 0 52 52" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M22.8176 23.2291C22.8176 23.8558 22.6942 24.4763 22.4544 25.0552C22.2146 25.6342 21.8631 26.1602 21.42 26.6033C20.9769 27.0464 20.4509 27.3979 19.8719 27.6377C19.293 27.8775 18.6725 28.0009 18.0458 28.0009C17.4192 28.0009 16.7987 27.8775 16.2197 27.6377C15.6408 27.3979 15.1148 27.0464 14.6717 26.6033C14.2286 26.1602 13.8771 25.6342 13.6373 25.0552C13.3975 24.4763 13.274 23.8558 13.274 23.2291C13.274 21.9636 13.7768 20.7498 14.6717 19.8549C15.5665 18.9601 16.7803 18.4573 18.0458 18.4573C19.3114 18.4573 20.5251 18.9601 21.42 19.8549C22.3149 20.7498 22.8176 21.9636 22.8176 23.2291ZM20.1666 23.2291C20.1666 22.6666 19.9432 22.1272 19.5455 21.7295C19.1477 21.3318 18.6083 21.1083 18.0458 21.1083C17.4834 21.1083 16.9439 21.3318 16.5462 21.7295C16.1485 22.1272 15.925 22.6666 15.925 23.2291C15.925 23.7916 16.1485 24.331 16.5462 24.7288C16.9439 25.1265 17.4834 25.3499 18.0458 25.3499C18.6083 25.3499 19.1477 25.1265 19.5455 24.7288C19.9432 24.331 20.1666 23.7916 20.1666 23.2291ZM18.0458 39.6653C19.3114 39.6653 20.5251 39.1626 21.42 38.2677C22.3149 37.3728 22.8176 36.1591 22.8176 34.8935C22.8176 33.628 22.3149 32.4142 21.42 31.5194C20.5251 30.6245 19.3114 30.1217 18.0458 30.1217C16.7803 30.1217 15.5665 30.6245 14.6717 31.5194C13.7768 32.4142 13.274 33.628 13.274 34.8935C13.274 36.1591 13.7768 37.3728 14.6717 38.2677C15.5665 39.1626 16.7803 39.6653 18.0458 39.6653ZM18.0458 37.0143C17.4834 37.0143 16.9439 36.7909 16.5462 36.3932C16.1485 35.9954 15.925 35.456 15.925 34.8935C15.925 34.3311 16.1485 33.7916 16.5462 33.3939C16.9439 32.9962 17.4834 32.7727 18.0458 32.7727C18.6083 32.7727 19.1477 32.9962 19.5455 33.3939C19.9432 33.7916 20.1666 34.3311 20.1666 34.8935C20.1666 35.456 19.9432 35.9954 19.5455 36.3932C19.1477 36.7909 18.6083 37.0143 18.0458 37.0143ZM14.5995 13.1553C14.248 13.1553 13.9108 13.295 13.6623 13.5435C13.4137 13.7921 13.274 14.1293 13.274 14.4808C13.274 14.8324 13.4137 15.1695 13.6623 15.4181C13.9108 15.6667 14.248 15.8063 14.5995 15.8063H37.3981C37.7497 15.8063 38.0868 15.6667 38.3354 15.4181C38.584 15.1695 38.7236 14.8324 38.7236 14.4808C38.7236 14.1293 38.584 13.7921 38.3354 13.5435C38.0868 13.295 37.7497 13.1553 37.3981 13.1553H14.5995ZM24.9384 23.4942C24.9384 22.7625 25.5323 22.1687 26.2639 22.1687H37.3981C37.7497 22.1687 38.0868 22.3084 38.3354 22.5569C38.584 22.8055 38.7236 23.1427 38.7236 23.4942C38.7236 23.8458 38.584 24.1829 38.3354 24.4315C38.0868 24.6801 37.7497 24.8197 37.3981 24.8197H26.2639C25.5323 24.8197 24.9384 24.2259 24.9384 23.4942ZM26.2639 33.3029C25.9124 33.3029 25.5752 33.4426 25.3267 33.6912C25.0781 33.9397 24.9384 34.2769 24.9384 34.6284C24.9384 34.98 25.0781 35.3171 25.3267 35.5657C25.5752 35.8143 25.9124 35.9539 26.2639 35.9539H37.3981C37.7497 35.9539 38.0868 35.8143 38.3354 35.5657C38.584 35.3171 38.7236 34.98 38.7236 34.6284C38.7236 34.2769 38.584 33.9397 38.3354 33.6912C38.0868 33.4426 37.7497 33.3029 37.3981 33.3029H26.2639ZM13.5391 6.79291C11.7814 6.79291 10.0957 7.49116 8.85277 8.73406C7.60987 9.97696 6.91162 11.6627 6.91162 13.4204V38.3398C6.91162 40.0976 7.60987 41.7833 8.85277 43.0262C10.0957 44.2691 11.7814 44.9673 13.5391 44.9673H38.4585C40.2163 44.9673 41.902 44.2691 43.1449 43.0262C44.3878 41.7833 45.0861 40.0976 45.0861 38.3398V13.4204C45.0861 11.6627 44.3878 9.97696 43.1449 8.73406C41.902 7.49116 40.2163 6.79291 38.4585 6.79291H13.5391ZM9.56262 13.4204C9.56262 12.3658 9.98158 11.3543 10.7273 10.6086C11.4731 9.86286 12.4845 9.44391 13.5391 9.44391H38.4585C39.5132 9.44391 40.5246 9.86286 41.2704 10.6086C42.0161 11.3543 42.4351 12.3658 42.4351 13.4204V38.3398C42.4351 39.3945 42.0161 40.4059 41.2704 41.1516C40.5246 41.8974 39.5132 42.3163 38.4585 42.3163H13.5391C12.4845 42.3163 11.4731 41.8974 10.7273 41.1516C9.98158 40.4059 9.56262 39.3945 9.56262 38.3398V13.4204Z" fill="#3A3A85"/>
</svg>


          </div>
          <div className={meed}>Know Your Customer (KYC)</div>
          <div className={bttm}>
          Complying with Know Your Customer (KYC) rules and regulations no longer needs to be a burden to your financial institution. ISSL has developed a KYC product that adheres to global industry standards and best practices, yet can be tailored to suit regional regulatory requirements



          </div>
        </div>

        <div className={twgridbod}>
          <div className={toop}>
     


          <svg width="57" height="61" viewBox="0 0 57 61" fill="none" xmlns="http://www.w3.org/2000/svg">
<circle cx="17.0633" cy="16.5353" r="16.2137" fill="#3A3A85" fill-opacity="0.15"/>
<path d="M46.7547 12.6028H53.1172V18.9653H46.7547V12.6028ZM46.7547 22.1465H53.1172V28.509H46.7547V22.1465ZM37.2109 12.6028H43.5734V18.9653H37.2109V12.6028ZM37.2109 22.1465H43.5734V28.509H37.2109V22.1465Z" fill="#3A3A85"/>
<path d="M49.936 34.8716V44.4153H11.761V18.9653H30.8485V15.7841H11.761C10.9172 15.7841 10.1081 16.1192 9.51148 16.7158C8.91488 17.3124 8.57971 18.1216 8.57971 18.9653V44.4153C8.57971 45.259 8.91488 46.0682 9.51148 46.6648C10.1081 47.2614 10.9172 47.5966 11.761 47.5966H24.486V53.9591H18.1235V57.1403H43.5735V53.9591H37.211V47.5966H49.936C50.7797 47.5966 51.5888 47.2614 52.1854 46.6648C52.782 46.0682 53.1172 45.259 53.1172 44.4153V34.8716H49.936ZM34.0297 53.9591H27.6672V47.5966H34.0297V53.9591Z" fill="#3A3A85"/>
</svg>

              

          </div>
          <div className={meed}>Online Banking</div>
          <div className={bttm}>
          To retain current clients and attract new ones, you need to offer your clients the best solutions to bank online. ISSL’s customizable electronic banking solutions will simplify your customers’ banking experience by enabling them to conduct online banking transactions at any time of day or night, such as making transfers between personal and external accounts, checking account status, setting up standing orders and direct debits, paying utility bills and more.



          </div>
        </div>



        <div className={twgridbod}>
          <div className={toop}>
     

 
<svg width="56" height="61" viewBox="0 0 56 61" fill="none" xmlns="http://www.w3.org/2000/svg">
<circle cx="16.2137" cy="16.5353" r="16.2137" fill="#3A3A85" fill-opacity="0.15"/>
<path d="M38.4823 13.6632H21.5156C19.173 13.6632 17.2739 15.5623 17.2739 17.9049V51.8382C17.2739 54.1808 19.173 56.0799 21.5156 56.0799H38.4823C40.8249 56.0799 42.7239 54.1808 42.7239 51.8382V17.9049C42.7239 15.5623 40.8249 13.6632 38.4823 13.6632Z" stroke="#3A3A85" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M29.8928 47.5966H30.1049" stroke="#3A3A85" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>

              

          </div>
          <div className={meed}>Mobile Banking</div>
          <div className={bttm}>
  
ISSL’s mobile banking software is available as both an App and with SMS, and can be easily integrated into your existing technology interface. Similar to our online banking software, our customizable mobile solution will simplify your customers’ banking experience by enabling them to conduct a number of banking transactions on their regular phones, smart phones and tablets. Some of these transactions include viewing account balances and statements, as well as transferring funds internally between accounts and to external accounts.

          </div>
        </div>

  

      </div>
    </div>
  </div>
  {/* footer */}
</div>


<Myfooter />
  
</>

)

export default Isslbankingsolutions